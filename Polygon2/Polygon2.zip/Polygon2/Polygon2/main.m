//
//  main.m
//  Polygon2
//
//  Created by John Lindner on 2/23/16.
//  Copyright © 2016 John Lindner. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
