//
//  main.m
//  Spring
//
//  Created by John Lindner on 4/2/16.
//  Copyright © 2016 John Lindner. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
