//
//  main.m
//  FrstView
//
//  Created by Avi Vajpeyi on 2/15/16.
//  Copyright © 2016 Avi Vajpeyi. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
